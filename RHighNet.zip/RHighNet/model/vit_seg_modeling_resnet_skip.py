import math

from os.path import join as pjoin
from collections import OrderedDict

import torch
import torch.nn as nn
import torch.nn.functional as F

from mmcv.cnn import ConvModule

class SqueezeAndExcitation(nn.Module):
    def __init__(self, channel,
                 reduction=16, activation=nn.ReLU(inplace=True)):
        super(SqueezeAndExcitation, self).__init__()
        self.fc = nn.Sequential(
            nn.Conv2d(channel, channel // reduction, kernel_size=1),
            activation,
            nn.Conv2d(channel // reduction, channel, kernel_size=1),
            nn.Sigmoid()
        )

    def forward(self, x):
        weighting = F.adaptive_avg_pool2d(x, 1)
        weighting = self.fc(weighting)
        y = x * weighting
        return y
    
class SqueezeAndExciteFusionAdd(nn.Module):
    def __init__(self, channels_in, activation=nn.ReLU(inplace=True)):
        super(SqueezeAndExciteFusionAdd, self).__init__()

        self.se_rgb = SqueezeAndExcitation(channels_in,
                                           activation=activation)
        self.se_depth = SqueezeAndExcitation(channels_in,
                                             activation=activation)

    def forward(self, rgb, depth):
        rgb = self.se_rgb(rgb)
        depth = self.se_depth(depth)
        out = rgb + depth
        return out
    
def np2th(weights, conv=False):
    """Possibly convert HWIO to OIHW."""
    if conv:
        weights = weights.transpose([3, 2, 0, 1])
    return torch.from_numpy(weights)

########################
class CBAMLayer(nn.Module):
    def __init__(self, in_channels, out_channels, conv_cfg, norm_cfg, act_cfg, spatial_kernel=7):
        super(CBAMLayer, self).__init__()
        self.conv_bn_relu = ConvModule(in_channels, out_channels, 3, stride=1, padding=1, conv_cfg=conv_cfg,
                                       norm_cfg=norm_cfg, act_cfg=act_cfg)
        # spatial attention
        self.conv = nn.Conv2d(2, 1, kernel_size=spatial_kernel,
                              padding=spatial_kernel // 2, bias=False)
        self.sigmoid = nn.Sigmoid()
 
    def forward(self, x):
        x = self.conv_bn_relu(x)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        avg_out = torch.mean(x, dim=1, keepdim=True)
        spatial_out = self.conv(torch.cat([max_out, avg_out], dim=1))
        spatial_att = self.sigmoid(spatial_out)
        #x = spatial_out * x
        return x,spatial_att
#################
class ChannelAtt(nn.Module):
    def __init__(self, in_channels, out_channels, conv_cfg, norm_cfg, act_cfg):
        super(ChannelAtt, self).__init__()
        self.conv_bn_relu = ConvModule(in_channels, out_channels, 3, stride=1, padding=1, conv_cfg=conv_cfg,
                                       norm_cfg=norm_cfg, act_cfg=act_cfg)
        self.conv_1x1 = ConvModule(out_channels, out_channels, 1, stride=1, padding=0, conv_cfg=conv_cfg,
                                   norm_cfg=norm_cfg, act_cfg=None)

    def forward(self, x, fre=False):
        """Forward function."""
        feat = self.conv_bn_relu(x)
        if fre:
            h, w = feat.size()[2:]
            h_tv = torch.pow(feat[..., 1:, :] - feat[..., :h - 1, :], 2)
            w_tv = torch.pow(feat[..., 1:] - feat[..., :w - 1], 2)
            atten = torch.mean(h_tv, dim=(2, 3), keepdim=True) + torch.mean(w_tv, dim=(2, 3), keepdim=True)
        else:
            atten = torch.mean(feat, dim=(2, 3), keepdim=True)
        atten = self.conv_1x1(atten)
        return feat, atten

class RelationAwareFusion_spatial(nn.Module):
    def __init__(self, channels, sp_H,conv_cfg, norm_cfg, act_cfg, ext=1, r=16):
        super(RelationAwareFusion, self).__init__()
        self.r = r
        #self.sam1 = CBAMLayer(spatial_kernel=3)
        #self.sam2 = CBAMLayer(spatial_kernel=3)
        self.g1 = nn.Parameter(torch.zeros(1))
        self.g2 = nn.Parameter(torch.zeros(1))
        #self.spatial_mlp = nn.Sequential(nn.Linear(channels * 2, channels), nn.ReLU(), nn.Linear(channels, channels))
        self.spatial_mlp = nn.Sequential(nn.Linear(r*r, channels), nn.ReLU(), nn.Linear(channels, channels))
        self.spatial_att = CBAMLayer(channels * ext, channels, conv_cfg, norm_cfg, act_cfg)
        #self.context_mlp = nn.Sequential(*[nn.Linear(channels * 2, channels), nn.ReLU(), nn.Linear(channels, channels)])
        self.context_mlp = nn.Sequential(*[nn.Linear(r*r, channels), nn.ReLU(), nn.Linear(channels, channels)])
        self.context_att = CBAMLayer(channels, channels, conv_cfg, norm_cfg, act_cfg)
        self.context_head1 = ConvModule(channels, channels, 3, stride=1, padding=1, conv_cfg=conv_cfg, norm_cfg=norm_cfg,act_cfg=act_cfg)
        self.context_head2 = ConvModule(channels, channels, 3, stride=1, padding=1, conv_cfg=conv_cfg, norm_cfg=norm_cfg,act_cfg=act_cfg)
        self.smooth = ConvModule(channels, channels, 3, stride=1, padding=1, conv_cfg=conv_cfg, norm_cfg=norm_cfg,
                                 act_cfg=None)
        #self.biattention = BiAttention()

    def forward(self, sp_feat, co_feat):
        # **_att: B x C x 1 x 1
        #print("0----",sp_feat.shape,co_feat.shape)
        
        #sp_feat = self.sam1(sp_feat) 
        #co_feat = self.sam2(co_feat) 
        #print("1----",sp_feat.shape,co_feat.shape)
        #print(a)
        s_feat, s_att = self.spatial_att(sp_feat)
        c_feat, c_att = self.context_att(co_feat)
        b, c, h, w = s_att.size()
        s_att_split = s_att.view(b, self.r, c // self.r)
        c_att_split = c_att.view(b, self.r, c // self.r)
        chl_affinity = torch.bmm(s_att_split, c_att_split.permute(0, 2, 1))
        chl_affinity = chl_affinity.view(b, -1)
        #print(chl_affinity.shape)
        sp_mlp_out = F.relu(self.spatial_mlp(chl_affinity))
        co_mlp_out = F.relu(self.context_mlp(chl_affinity))
        re_s_att = torch.sigmoid(s_att + self.g1 * sp_mlp_out.unsqueeze(-1).unsqueeze(-1))
        re_c_att = torch.sigmoid(c_att + self.g2 * co_mlp_out.unsqueeze(-1).unsqueeze(-1))
        c_feat = torch.mul(c_feat, re_c_att)
        s_feat = torch.mul(s_feat, re_s_att)
        #print("1----",c_feat.shape,s_feat.shape)
        
        #c_feat = F.interpolate(c_feat, s_feat.size()[2:], mode='bilinear', align_corners=False)
        #print("2----",c_feat.shape,s_feat.shape)
        
        c_feat = self.context_head1(c_feat)
        s_feat = self.context_head2(s_feat)
        #print("3----",c_feat.shape,s_feat.shape)
        #print(a)
        out = self.smooth(s_feat + c_feat)
        #out = self.biattention(s_feat,c_feat)
        #print(s_feat.shape)
        #print(c_feat.shape)
        #print(out.shape)
        return out
        
class RelationAwareFusion(nn.Module):
    def __init__(self, channels, spatial_H,conv_cfg, norm_cfg, act_cfg, ext=1, r=16):
        super(RelationAwareFusion, self).__init__()
      
        self.r = r
        self.channels = channels
        self.ext = ext
        self.spatial_H=spatial_H
        #self.spatial_RAF  = RelationAwareFusion(self.channels, conv_cfg, norm_cfg, act_cfg, self.ext, self.r)
        #------------------------------spatial-----------------------------------
        self.g1_s = nn.Parameter(torch.zeros(1))
        self.g2_s = nn.Parameter(torch.zeros(1))
        #self.spatial_mlp = nn.Sequential(nn.Linear(channels * 2, channels), nn.ReLU(), nn.Linear(channels, channels))
        self.spatial_conv_s = nn.Sequential(
    nn.Conv2d(in_channels=1,  # 假设输入特征是单通道的
              out_channels=1,  # 假设输出特征也是单通道的
              kernel_size=3,
              stride=1,
              padding=int((spatial_H - 1) / 4),  # 计算适当的填充以保持输入输出特征大小
              dilation=2),  # 设置膨胀率
    nn.ReLU(),  # 激活函数
    nn.Conv2d(in_channels=1,  # 假设输入特征是单通道的
              out_channels=1,  # 输出特征是128x128
              kernel_size=5,
              stride=1,
              padding=int((spatial_H - 1) / 4),
              dilation=2),
)
        self.spatial_att_s = CBAMLayer(channels, channels, conv_cfg, norm_cfg, act_cfg,spatial_kernel=3)
        #self.context_mlp = nn.Sequential(*[nn.Linear(channels * 2, channels), nn.ReLU(), nn.Linear(channels, channels)])
        self.context_conv_s =nn.Sequential(
    nn.Conv2d(in_channels=1,  # 假设输入特征是单通道的
              out_channels=1,  # 假设输出特征也是单通道的
              kernel_size=3,
              stride=1,
              padding=int((spatial_H - 1) / 4),  # 计算适当的填充以保持输入输出特征大小
              dilation=2),  # 设置膨胀率
    nn.ReLU(),  # 激活函数
    nn.Conv2d(in_channels=1,  # 假设输入特征是单通道的
              out_channels=1,  # 输出特征是128x128
              kernel_size=5,
              stride=1,
              padding=int((spatial_H - 1) / 4),
              dilation=2),
)
        self.context_att_s = CBAMLayer(channels, channels, conv_cfg, norm_cfg, act_cfg,spatial_kernel=3)
        #self.context_head1_s = ConvModule(channels, channels, 3, stride=1, padding=1, conv_cfg=conv_cfg, norm_cfg=norm_cfg,act_cfg=act_cfg)
        #self.context_head2_s = ConvModule(channels, channels, 3, stride=1, padding=1, conv_cfg=conv_cfg, norm_cfg=norm_cfg,act_cfg=act_cfg)
        self.smooth_s = ConvModule(channels, channels, 3, stride=1, padding=1, conv_cfg=conv_cfg, norm_cfg=norm_cfg,
                                 act_cfg=None)
        #--------------------------------------------end----------------------------------
        #c_feat = F.interpolate(c_feat, s_feat.size()[2:], mode='bilinear', align_corners=False)
        self.g1 = nn.Parameter(torch.zeros(1))
        self.g2 = nn.Parameter(torch.zeros(1))
        #self.channel_w = nn.Parameter(torch.zeros(1))
        #self.spatial_w = nn.Parameter(torch.zeros(1))
        #self.spatial_mlp = nn.Sequential(nn.Linear(channels * 2, channels), nn.ReLU(), nn.Linear(channels, channels))
        self.spatial_mlp = nn.Sequential(nn.Linear(r*r, channels), nn.ReLU(), nn.Linear(channels, channels))
        self.spatial_att = ChannelAtt(channels * ext, channels, conv_cfg, norm_cfg, act_cfg)
        #self.context_mlp = nn.Sequential(*[nn.Linear(channels * 2, channels), nn.ReLU(), nn.Linear(channels, channels)])
        self.context_mlp = nn.Sequential(*[nn.Linear(r*r, channels), nn.ReLU(), nn.Linear(channels, channels)])
        self.context_att = ChannelAtt(channels, channels, conv_cfg, norm_cfg, act_cfg)
        #self.context_head1 = ConvModule(channels, channels, 3, stride=1, padding=1, conv_cfg=conv_cfg, norm_cfg=norm_cfg,act_cfg=act_cfg)
        #self.context_head2 = ConvModule(channels, channels, 3, stride=1, padding=1, conv_cfg=conv_cfg, norm_cfg=norm_cfg,act_cfg=act_cfg)
        self.smooth = ConvModule(channels, channels, 3, stride=1, padding=1, conv_cfg=conv_cfg, norm_cfg=norm_cfg,
                                 act_cfg=None)
        #self.biattention = BiAttention()
    def forward_channel(self,sp_feat,co_feat):
        s_feat, s_att = self.spatial_att(sp_feat)
        c_feat, c_att = self.context_att(co_feat)
        b, c, h, w = s_att.size()
        #print("3----",s_att.shape,c_att.shape)
        
        s_att_split = s_att.view(b, self.r, c // self.r)
        c_att_split = c_att.view(b, self.r, c // self.r)
        #print("4----",s_att_split.shape,c_att_split.shape)
        #print(a)
        chl_affinity = torch.bmm(s_att_split, c_att_split.permute(0, 2, 1))
        chl_affinity = chl_affinity.view(b, -1)
        #print(chl_affinity.shape)
        sp_mlp_out = F.relu(self.spatial_mlp(chl_affinity))
        co_mlp_out = F.relu(self.context_mlp(chl_affinity))
        re_s_att = torch.sigmoid(s_att + self.g1 * sp_mlp_out.unsqueeze(-1).unsqueeze(-1))
        re_c_att = torch.sigmoid(c_att + self.g2 * co_mlp_out.unsqueeze(-1).unsqueeze(-1))
        #print ("1----",c_feat.shape,re_c_att.shape)
        c_feat = torch.mul(c_feat, re_c_att)
        s_feat = torch.mul(s_feat, re_s_att)
        #print("1----",c_feat.shape,s_feat.shape)
        
        #c_feat = F.interpolate(c_feat, s_feat.size()[2:], mode='bilinear', align_corners=False)
        #print("2----",c_feat.shape,s_feat.shape)
        
        #c_feat = self.context_head1(c_feat)
        #s_feat = self.context_head2(s_feat)
        #print("3----",c_feat.shape,s_feat.shape)
        #print(a)
        out = self.smooth(s_feat + c_feat)
        return out
    def forward_spatial(self, sp_feat, co_feat): 
        s_feat, s_att = self.spatial_att_s(sp_feat)
        c_feat, c_att = self.context_att_s(co_feat)
        b, c, h, w = s_att.size()
        #print("--------------------------------------------1 s_feat- s_att---",s_feat.shape,s_att.shape)
        #print("1 c----",c_feat.shape,c_att.shape)
        s_att_split = s_att.view(b, self.r, (h*w) // self.r)
        c_att_split = c_att.view(b, self.r, (h*w)  // self.r)
        #print("s_att_splits----",s_att_split.shape)
        #print("c_att_split c----",c_att_split.shape)
        chl_affinity = torch.bmm(s_att_split, c_att_split.permute(0, 2, 1))
        #print("chl_affinity bmm ----",chl_affinity.shape)
        chl_affinity = chl_affinity.view(b, 1,self.r,self.r)
        #print("chl_affinity view ----",chl_affinity.shape)
        sp_mlp_out = F.relu(self.spatial_conv_s(chl_affinity))
        co_mlp_out = F.relu(self.context_conv_s(chl_affinity))
        
        sp_mlp_out = F.interpolate(sp_mlp_out, s_att.size()[2:], mode='bilinear', align_corners=False)
        co_mlp_out = F.interpolate(co_mlp_out, s_att.size()[2:], mode='bilinear', align_corners=False)
        #print("sp_mlp_out conv----",sp_mlp_out.shape)
        #print("co_mlp_out conv----",co_mlp_out.shape)
        re_s_att = torch.sigmoid(s_att + self.g1_s * sp_mlp_out)
        re_c_att = torch.sigmoid(c_att + self.g2_s * co_mlp_out)
        #print("re_s_att, s_att,self.g1,sp_mlp_out----",re_s_att.shape, s_att.shape,self.g1.shape,sp_mlp_out.shape)
        #print("re_c_att, c_att,self.g2,co_mlp_out----",re_c_att.shape, c_att.shape,self.g2.shape,co_mlp_out.shape)
        c_feat = torch.mul(c_feat, re_c_att)
        s_feat = torch.mul(s_feat, re_s_att)
        #print("mul----",c_feat.shape,re_c_att.shape)
        
        #c_feat = F.interpolate(c_feat, s_feat.size()[2:], mode='bilinear', align_corners=False)
        #print("2----",c_feat.shape,s_feat.shape)
        
        #c_feat = self.context_head2(c_feat)
        #s_feat = self.context_head2(s_feat)
        #print(" head----",c_feat.shape,s_feat.shape)
        #print(a)
        out = self.smooth_s(s_feat + c_feat)#+out_s
        #out = self.biattention(s_feat,c_feat)
        #print("out-----",out.shape)
        return out
    def forward(self, sp_feat, co_feat):
        # **_att: B x C x 1 x 1
        #print("0----",sp_feat.shape,co_feat.shape)
        
        #sp_feat = self.sam1(sp_feat) 
        #co_feat = self.sam2(co_feat) 
        _,_,hh,ww=  sp_feat.size()
        if hh%2!=0:
           sp_feat = F.interpolate(sp_feat, [hh+1,ww+1], mode='bilinear', align_corners=False)
           co_feat = F.interpolate(co_feat, [hh+1,ww+1], mode='bilinear', align_corners=False)
        #-------------------------------spatial-------------------------------
        out_spatial = self.forward_spatial(sp_feat, co_feat)
        out_channel = self.forward_channel(sp_feat, co_feat)
        out = out_spatial + out_channel
        #out = torch.cat([out_spatial, out_channel],dim=1)
        #out = self.biattention(s_feat,c_feat)
        #print("out-----",out.shape)
        #print(a)
       
        return out
#################

class StdConv2d(nn.Conv2d):

    def forward(self, x):
        w = self.weight
        v, m = torch.var_mean(w, dim=[1, 2, 3], keepdim=True, unbiased=False)
        w = (w - m) / torch.sqrt(v + 1e-5)
        return F.conv2d(x, w, self.bias, self.stride, self.padding,
                        self.dilation, self.groups)


def conv3x3(cin, cout, stride=1, groups=1, bias=False):
    return StdConv2d(cin, cout, kernel_size=3, stride=stride,
                     padding=1, bias=bias, groups=groups)


def conv1x1(cin, cout, stride=1, bias=False):
    return StdConv2d(cin, cout, kernel_size=1, stride=stride,
                     padding=0, bias=bias)


class PreActBottleneck(nn.Module):
    """Pre-activation (v2) bottleneck block.
    """

    def __init__(self, cin, cout=None, cmid=None, stride=1):
        super().__init__()
        cout = cout or cin
        cmid = cmid or cout//4

        self.gn1 = nn.GroupNorm(32, cmid, eps=1e-6)
        self.conv1 = conv1x1(cin, cmid, bias=False)
        self.gn2 = nn.GroupNorm(32, cmid, eps=1e-6)
        self.conv2 = conv3x3(cmid, cmid, stride, bias=False)  # Original code has it on conv1!!
        self.gn3 = nn.GroupNorm(32, cout, eps=1e-6)
        self.conv3 = conv1x1(cmid, cout, bias=False)
        self.relu = nn.ReLU(inplace=True)

        if (stride != 1 or cin != cout):
            # Projection also with pre-activation according to paper.
            self.downsample = conv1x1(cin, cout, stride, bias=False)
            self.gn_proj = nn.GroupNorm(cout, cout)

    def forward(self, x):

        # Residual branch
        residual = x
        if hasattr(self, 'downsample'):
            residual = self.downsample(x)
            residual = self.gn_proj(residual)

        # Unit's branch
        y = self.relu(self.gn1(self.conv1(x)))
        y = self.relu(self.gn2(self.conv2(y)))
        y = self.gn3(self.conv3(y))

        #y = self.relu(residual + y)
        y = self.relu(residual - y)
        return y

    def load_from(self, weights, n_block, n_unit):
        conv1_weight = np2th(weights[pjoin(n_block, n_unit, "conv1/kernel")], conv=True)
        conv2_weight = np2th(weights[pjoin(n_block, n_unit, "conv2/kernel")], conv=True)
        conv3_weight = np2th(weights[pjoin(n_block, n_unit, "conv3/kernel")], conv=True)

        gn1_weight = np2th(weights[pjoin(n_block, n_unit, "gn1/scale")])
        gn1_bias = np2th(weights[pjoin(n_block, n_unit, "gn1/bias")])

        gn2_weight = np2th(weights[pjoin(n_block, n_unit, "gn2/scale")])
        gn2_bias = np2th(weights[pjoin(n_block, n_unit, "gn2/bias")])

        gn3_weight = np2th(weights[pjoin(n_block, n_unit, "gn3/scale")])
        gn3_bias = np2th(weights[pjoin(n_block, n_unit, "gn3/bias")])

        self.conv1.weight.copy_(conv1_weight)
        self.conv2.weight.copy_(conv2_weight)
        self.conv3.weight.copy_(conv3_weight)

        self.gn1.weight.copy_(gn1_weight.view(-1))
        self.gn1.bias.copy_(gn1_bias.view(-1))

        self.gn2.weight.copy_(gn2_weight.view(-1))
        self.gn2.bias.copy_(gn2_bias.view(-1))

        self.gn3.weight.copy_(gn3_weight.view(-1))
        self.gn3.bias.copy_(gn3_bias.view(-1))

        if hasattr(self, 'downsample'):
            proj_conv_weight = np2th(weights[pjoin(n_block, n_unit, "conv_proj/kernel")], conv=True)
            proj_gn_weight = np2th(weights[pjoin(n_block, n_unit, "gn_proj/scale")])
            proj_gn_bias = np2th(weights[pjoin(n_block, n_unit, "gn_proj/bias")])

            self.downsample.weight.copy_(proj_conv_weight)
            self.gn_proj.weight.copy_(proj_gn_weight.view(-1))
            self.gn_proj.bias.copy_(proj_gn_bias.view(-1))

class ResNetV2(nn.Module):
    """Implementation of Pre-activation (v2) ResNet mode."""

    def __init__(self, block_units, width_factor):
        super().__init__()
        width = int(64 * width_factor)
        self.width = width

        self.root = nn.Sequential(OrderedDict([
            ('conv', StdConv2d(4, width, kernel_size=7, stride=2, bias=False, padding=3)),
            ('gn', nn.GroupNorm(32, width, eps=1e-6)),
            ('relu', nn.ReLU(inplace=True)),
            # ('pool', nn.MaxPool2d(kernel_size=3, stride=2, padding=0))
        ]))

        self.body = nn.Sequential(OrderedDict([
            ('block1', nn.Sequential(OrderedDict(
                [('unit1', PreActBottleneck(cin=width, cout=width*4, cmid=width))] +
                [(f'unit{i:d}', PreActBottleneck(cin=width*4, cout=width*4, cmid=width)) for i in range(2, block_units[0] + 1)],
                ))),
            ('block2', nn.Sequential(OrderedDict(
                [('unit1', PreActBottleneck(cin=width*4, cout=width*8, cmid=width*2, stride=2))] +
                [(f'unit{i:d}', PreActBottleneck(cin=width*8, cout=width*8, cmid=width*2)) for i in range(2, block_units[1] + 1)],
                ))),
            ('block3', nn.Sequential(OrderedDict(
                [('unit1', PreActBottleneck(cin=width*8, cout=width*16, cmid=width*4, stride=2))] +
                [(f'unit{i:d}', PreActBottleneck(cin=width*16, cout=width*16, cmid=width*4)) for i in range(2, block_units[2] + 1)],
                ))),
        ]))

    def forward(self, x):
        features = []
        b, c, in_size, _ = x.size()
        x = self.root(x)
        features.append(x)
        x = nn.MaxPool2d(kernel_size=3, stride=2, padding=0)(x)
        for i in range(len(self.body)-1):
            x = self.body[i](x)
            right_size = int(in_size / 4 / (i+1))
            if x.size()[2] != right_size:
                pad = right_size - x.size()[2]
                assert pad < 3 and pad > 0, "x {} should {}".format(x.size(), right_size)
                feat = torch.zeros((b, x.size()[1], right_size, right_size), device=x.device)
                feat[:, :, 0:x.size()[2], 0:x.size()[3]] = x[:]
            else:
                feat = x
            features.append(feat)
        x = self.body[-1](x)
        return x, features[::-1]


from torch.nn import Module, Sequential, Conv2d, ReLU,AdaptiveMaxPool2d, AdaptiveAvgPool2d, \
    NLLLoss, BCELoss, CrossEntropyLoss, AvgPool2d, MaxPool2d, Parameter, Linear, Sigmoid, Softmax, Dropout, Embedding        
class PAM_Module(Module):
    """ Position attention module"""
    #Ref from SAGAN
    def __init__(self, in_dim):
        super(PAM_Module, self).__init__()
        self.chanel_in = in_dim

        self.query_conv = Conv2d(in_channels=in_dim, out_channels=in_dim//8, kernel_size=1)
        self.key_conv = Conv2d(in_channels=in_dim, out_channels=in_dim//8, kernel_size=1)
        self.value_conv = Conv2d(in_channels=in_dim, out_channels=in_dim, kernel_size=1)
        self.gamma = Parameter(torch.zeros(1))

        self.softmax = Softmax(dim=-1)
    def forward(self, x):
        """
            inputs :
                x : input feature maps( B X C X H X W)
            returns :
                out : attention value + input feature
                attention: B X (HxW) X (HxW)
        """
        m_batchsize, C, height, width = x.size()
        proj_query = self.query_conv(x).view(m_batchsize, -1, width*height).permute(0, 2, 1)
        proj_key = self.key_conv(x).view(m_batchsize, -1, width*height)
        energy = torch.bmm(proj_query, proj_key)
        attention = self.softmax(energy)
        proj_value = self.value_conv(x).view(m_batchsize, -1, width*height)

        out = torch.bmm(proj_value, attention.permute(0, 2, 1))
        out = out.view(m_batchsize, C, height, width)

        out = self.gamma*out + x
        return out
      
from torch.cuda.amp import autocast

class ConvLayer(nn.Module):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size=3,
        stride=1,
        dilation=1,
        groups=1,
        use_bias=False,
        dropout=0.01,
        norm="bn2d",
        act_func="relu",
    ):
        super(ConvLayer, self).__init__()

        padding = get_same_padding(kernel_size)
        padding *= dilation

        self.dropout = nn.Dropout2d(dropout, inplace=False) if dropout > 0 else None
        self.conv = nn.Conv2d(
            in_channels,
            out_channels,
            kernel_size=(kernel_size, kernel_size),
            stride=(stride, stride),
            padding=padding,
            dilation=(dilation, dilation),
            groups=groups,
            bias=use_bias,
        )
        self.norm = build_norm(norm, num_features=out_channels)
        self.act = build_act(act_func)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.dropout is not None:
            x = self.dropout(x)
        x = self.conv(x)
        if self.norm:
            x = self.norm(x)
        if self.act:
            x = self.act(x)
        return x
from inspect import signature
def get_same_padding(kernel_size: int or tuple[int, ...]) -> int or tuple[int, ...]:
    if isinstance(kernel_size, tuple):
        return tuple([get_same_padding(ks) for ks in kernel_size])
    else:
        assert kernel_size % 2 > 0, "kernel size should be odd number"
        return kernel_size // 2
def build_kwargs_from_config(config: dict, target_func: callable) -> dict[str, any]:
    valid_keys = list(signature(target_func).parameters)
    kwargs = {}
    for key in config:
        if key in valid_keys:
            kwargs[key] = config[key]
    return kwargs
from functools import partial
REGISTERED_ACT_DICT: dict[str, type] = {
    "relu": nn.ReLU,
    "relu6": nn.ReLU6,
    "hswish": nn.Hardswish,
    "silu": nn.SiLU,
    "gelu": partial(nn.GELU, approximate="tanh"),
}


def build_act(name: str, **kwargs) -> nn.Module or None:
    if name in REGISTERED_ACT_DICT:
        act_cls = REGISTERED_ACT_DICT[name]
        args = build_kwargs_from_config(kwargs, act_cls)
        return act_cls(**args)
    else:
        return None
class LayerNorm2d(nn.LayerNorm):
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = x - torch.mean(x, dim=1, keepdim=True)
        out = out / torch.sqrt(torch.square(out).mean(dim=1, keepdim=True) + self.eps)
        if self.elementwise_affine:
            out = out * self.weight.view(1, -1, 1, 1) + self.bias.view(1, -1, 1, 1)
        return out
REGISTERED_NORM_DICT: dict[str, type] = {
    "bn2d": nn.BatchNorm2d,
    "ln": nn.LayerNorm,
    "ln2d": LayerNorm2d,
}
def build_norm(name="bn2d", num_features=None, **kwargs) -> nn.Module or None:
    if name in ["ln", "ln2d"]:
        kwargs["normalized_shape"] = num_features
    else:
        kwargs["num_features"] = num_features
    if name in REGISTERED_NORM_DICT:
        norm_cls = REGISTERED_NORM_DICT[name]
        args = build_kwargs_from_config(kwargs, norm_cls)
        return norm_cls(**args)
    else:
        return None
def val2tuple(x: list or tuple or any, min_len: int = 1, idx_repeat: int = -1) -> tuple:
    x = val2list(x)

    # repeat elements if necessary
    if len(x) > 0:
        x[idx_repeat:idx_repeat] = [x[idx_repeat] for _ in range(min_len - len(x))]

    return tuple(x)
def val2list(x: list or tuple or any, repeat_time=1) -> list:
    if isinstance(x, (list, tuple)):
        return list(x)
    return [x for _ in range(repeat_time)]

# 轻量权重多尺度注意力
class LiteMLA(nn.Module):
    r"""Lightweight multi-scale linear attention"""
 
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        heads: int or None = None,
        heads_ratio: float = 1.0,
        dim=8,
        use_bias=False,
        norm=(None, "bn2d"),
        act_func=(None, None),
        kernel_func="relu",
        scales: tuple[int, ...] = (5,),
        eps=1.0e-15,
    ):
        super(LiteMLA, self).__init__()
        self.eps = eps
        heads = heads or int(in_channels // dim * heads_ratio)
 
        total_dim = heads * dim
 
        use_bias = val2tuple(use_bias, 2)
        norm = val2tuple(norm, 2)
        act_func = val2tuple(act_func, 2)
 
        self.dim = dim
        self.qkv = ConvLayer(
            in_channels,
            3 * total_dim,
            1,
            use_bias=use_bias[0],
            norm=norm[0],
            act_func=act_func[0],
        )
        self.aggreg = nn.ModuleList(
            [
                nn.Sequential(
                    nn.Conv2d(
                        3 * total_dim,
                        3 * total_dim,
                        scale,
                        padding=get_same_padding(scale),
                        groups=3 * total_dim,
                        bias=use_bias[0],
                    ),
                    nn.Conv2d(3 * total_dim, 3 * total_dim, 1, groups=3 * heads, bias=use_bias[0]),
                )
                for scale in scales
            ]
        )              # nn.Conv2d()函数中的groups参数是指将输入和输出通道分成几组进行卷积操作
        self.kernel_func = build_act(kernel_func, inplace=False)    # Relu激活函数
 
        self.proj = ConvLayer(
            total_dim * (1 + len(scales)),
            out_channels,
            1,
            use_bias=use_bias[1],
            norm=norm[1],
            act_func=act_func[1],
        )
 
    @autocast(enabled=False)
    def relu_linear_att(self, qkv: torch.Tensor) -> torch.Tensor:
        B, _, H, W = list(qkv.size())
 
        if qkv.dtype == torch.float16:
            qkv = qkv.float()
 
        qkv = torch.reshape(
            qkv,
            (
                B,
                -1,
                3 * self.dim,
                H * W,
            ),
        )
        qkv = torch.transpose(qkv, -1, -2)
        q, k, v = (
            qkv[..., 0 : self.dim],
            qkv[..., self.dim : 2 * self.dim],
            qkv[..., 2 * self.dim :],
        )
 
        # lightweight linear attention
        q = self.kernel_func(q)     # 进行relu激活
        k = self.kernel_func(k)     # 进行relu激活
 
        # linear matmul
        trans_k = k.transpose(-1, -2)
 
        v = F.pad(v, (0, 1), mode="constant", value=1)      # 进行维度扩展
        kv = torch.matmul(trans_k, v)       # 按推导公式计算
        out = torch.matmul(q, kv)
        out = out[..., :-1] / (out[..., -1:] + self.eps)
 
        out = torch.transpose(out, -1, -2)
        out = torch.reshape(out, (B, -1, H, W))
        return out
 
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # generate multi-scale q, k, v
        qkv = self.qkv(x)               # 获取Q、K、V，由1x1卷积得到
        multi_scale_qkv = [qkv]
        for op in self.aggreg:          # 卷积聚合，学习通道上的多尺度信息
            multi_scale_qkv.append(op(qkv))
        multi_scale_qkv = torch.cat(multi_scale_qkv, dim=1)     # Q、K、V拼接
 
        out = self.relu_linear_att(multi_scale_qkv)     # 重新等分划分为Q，K，V，馈入ReLU线性注意力
        out = self.proj(out)        # 1x1卷积输出，模拟线性层
 
        return out
#########################


class FuseResNetV2(nn.Module):
    """Implementation of Pre-activation (v2) ResNet mode."""

    def __init__(self, block_units, width_factor):
        super().__init__()
        width = int(64 * width_factor)
        self.width = width
        self.activation=nn.ReLU(inplace=True)

        self.root = nn.Sequential(OrderedDict([
            ('conv', StdConv2d(3, width, kernel_size=7, stride=2, bias=False, padding=3)),
            ('gn', nn.GroupNorm(32, width, eps=1e-6)),
            ('relu', nn.ReLU(inplace=True)),
            # ('pool', nn.MaxPool2d(kernel_size=3, stride=2, padding=0))
        ]))
        
        self.rootd = nn.Sequential(OrderedDict([
            ('conv', StdConv2d(1, width, kernel_size=7, stride=2, bias=False, padding=3)),
            ('gn', nn.GroupNorm(32, width, eps=1e-6)),
            ('relu', nn.ReLU(inplace=True)),
            # ('pool', nn.MaxPool2d(kernel_size=3, stride=2, padding=0))
        ]))
        
        '''
        self.se_layer0 = SqueezeAndExciteFusionAdd(
            64, activation=self.activation)
        self.se_layer1 = SqueezeAndExciteFusionAdd(
            256,
            activation=self.activation)
        self.se_layer2 = SqueezeAndExciteFusionAdd(
            512,
            activation=self.activation)
        self.se_layer3 = SqueezeAndExciteFusionAdd(
            1024,
            activation=self.activation)
        '''
        
        self.se_layer0 = RelationAwareFusion(64,128,conv_cfg = dict(type='Conv2d'), norm_cfg = dict(type='BN'), act_cfg=dict(type='ReLU'), ext = 1, r = 32)
        
        self.se_layer1 = RelationAwareFusion(256, 64,conv_cfg = dict(type='Conv2d'), norm_cfg = dict(type='BN'), act_cfg=dict(type='ReLU'), ext = 1, r = 32)
        
        self.se_layer2 = RelationAwareFusion(512, 32,conv_cfg = dict(type='Conv2d'), norm_cfg = dict(type='BN'), act_cfg=dict(type='ReLU'), ext = 1, r = 32)
        
        self.se_layer3 = RelationAwareFusion(1024,16,conv_cfg = dict(type='Conv2d'), norm_cfg = dict(type='BN'), act_cfg=dict(type='ReLU'), ext = 1, r = 32)
        
        self.body = nn.Sequential(OrderedDict([
            ('block1', nn.Sequential(OrderedDict(
                [('unit1', PreActBottleneck(cin=width, cout=width*4, cmid=width))] +
                [(f'unit{i:d}', PreActBottleneck(cin=width*4, cout=width*4, cmid=width)) for i in range(2, block_units[0] + 1)],
                ))),
            ('block2', nn.Sequential(OrderedDict(
                [('unit1', PreActBottleneck(cin=width*4, cout=width*8, cmid=width*2, stride=2))] +
                [(f'unit{i:d}', PreActBottleneck(cin=width*8, cout=width*8, cmid=width*2)) for i in range(2, block_units[1] + 1)],
                ))),
            ('block3', nn.Sequential(OrderedDict(
                [('unit1', PreActBottleneck(cin=width*8, cout=width*16, cmid=width*4, stride=2))] +
                [(f'unit{i:d}', PreActBottleneck(cin=width*16, cout=width*16, cmid=width*4)) for i in range(2, block_units[2] + 1)],
                ))),
        ]))
    
        self.bodyd = nn.Sequential(OrderedDict([
            ('block1', nn.Sequential(OrderedDict(
                [('unit1', PreActBottleneck(cin=width, cout=width*4, cmid=width))] +
                [(f'unit{i:d}', PreActBottleneck(cin=width*4, cout=width*4, cmid=width)) for i in range(2, block_units[0] + 1)],
                ))),
            ('block2', nn.Sequential(OrderedDict(
                [('unit1', PreActBottleneck(cin=width*4, cout=width*8, cmid=width*2, stride=2))] +
                [(f'unit{i:d}', PreActBottleneck(cin=width*8, cout=width*8, cmid=width*2)) for i in range(2, block_units[1] + 1)],
                ))),
            ('block3', nn.Sequential(OrderedDict(
                [('unit1', PreActBottleneck(cin=width*8, cout=width*16, cmid=width*4, stride=2))] +
                [(f'unit{i:d}', PreActBottleneck(cin=width*16, cout=width*16, cmid=width*4)) for i in range(2, block_units[2] + 1)],
                ))),
        ]))
        
        #self.sam = CBAMLayer(spatial_kernel=7)
        #self.hie = BilinearAttention(in_channels=64)
        #self.pat = PAM_Module(in_dim=64)
        #self.la = LiteMLA(in_channels=64,out_channels=64)

    def forward(self, x, y):
        SE = True
        # SE = False
        features = []
        b, c, in_size, _ = x.size()
        #print(x.shape)
        #print(y.shape)
        x = self.root(x) #64*128
        #y = self.rootd(y) #64*128
        y = self.root(y)
        #x = self.sam(x)
        #y = self.sam(y)
        #x = self.hie(x)
        #y = self.hie(y)
        #x = self.pat(x)
        #y = self.pat(y)
        #x = self.la(x)
        #y = self.la(y)
        #print(x.shape)
        if SE:
            x = self.se_layer0(x, y)
        features.append(x)
        x = nn.MaxPool2d(kernel_size=3, stride=2, padding=0)(x)
        y = nn.MaxPool2d(kernel_size=3, stride=2, padding=0)(y)
        for i in range(len(self.body)-1):
            x = self.body[i](x) #256*63, 512*32
            #y = self.bodyd[i](y) #256*63, 512*32
            y = self.body[i](y)
            #print(x.shape)
            if SE:
                if i == 0:
                    x = self.se_layer1(x, y)
                if i == 1:
                    x = self.se_layer2(x, y)
                
            right_size = int(in_size / 4 / (i+1))
            if x.size()[2] != right_size:
                pad = right_size - x.size()[2]
                assert pad < 3 and pad > 0, "x {} should {}".format(x.size(), right_size)
                feat = torch.zeros((b, x.size()[1], right_size, right_size), device=x.device)
                feat[:, :, 0:x.size()[2], 0:x.size()[3]] = x[:]
            else:
                feat = x
            features.append(feat)
        x = self.body[-1](x) # 1024*16
        #y = self.bodyd[-1](y) # 1024*16
        y = self.body[-1](y)
        #print(x.shape)
        if SE:
            x = self.se_layer3(x, y)
        return x, y, features[::-1]
